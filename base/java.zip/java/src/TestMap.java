import java.util.Map;
import java.util.HashMap;
class TestMap{
    public static void mian(String[] args){
        Map m = new HashMap();
        m.put("name","rolin");
        System.out.println(m.size());

    }


}
