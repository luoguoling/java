package com.bdqn.service;

import com.bdqn.inf.UsersService;

public class UsersServiceImp implements UsersService {

	@Override
	public boolean login(String parUserName, String parPassWord)
			throws Exception {
		throw new Exception("ע��˷������뱻��д!");
	}

}
