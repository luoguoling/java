package com.bdqn.inf;

public interface UsersService {
	public boolean login(String parUserName,String parPassWord) throws Exception;
}
