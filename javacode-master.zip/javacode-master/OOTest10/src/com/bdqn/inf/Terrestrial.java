package com.bdqn.inf;

public interface Terrestrial {
	public int getLegnum();
}
