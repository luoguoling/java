package com.bdqn.domain;

public class Dolphin extends Animal{
	public Dolphin(String name, int legnum) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void shout() {
		// TODO Auto-generated method stub
		System.out.println("��������������");
	}
}
