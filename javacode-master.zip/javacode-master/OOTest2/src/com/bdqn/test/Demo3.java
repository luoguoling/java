package com.bdqn.test;

import com.bdqn.domain.Dog;

public class Demo3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog myDog = new Dog();
	}

}
