package com.bdqn.inf;

public interface SE {
	public void writerCoding();
}
