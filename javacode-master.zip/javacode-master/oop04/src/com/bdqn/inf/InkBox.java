package com.bdqn.inf;

public interface InkBox {
	public String getColor();
}
