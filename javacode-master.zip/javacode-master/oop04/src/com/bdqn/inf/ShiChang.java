package com.bdqn.inf;

public interface ShiChang {
	public void speakYW();
}
