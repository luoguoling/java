package com.bdqn.inf;

public interface IPaper {
	int TYPE=1;
	public String paperSize();
}
