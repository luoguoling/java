package com.bdqn.inf;

public interface IUsb {
	public void inputData();
	public void outputData();
}
