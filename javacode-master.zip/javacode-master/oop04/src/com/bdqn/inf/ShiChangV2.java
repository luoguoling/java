package com.bdqn.inf;

public interface ShiChangV2 extends ShiChang{
	public void hejiu();
}
