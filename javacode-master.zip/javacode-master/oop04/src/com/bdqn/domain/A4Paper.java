package com.bdqn.domain;

import com.bdqn.inf.IPaper;

public class A4Paper implements IPaper {

	@Override
	public String paperSize() {
		// TODO Auto-generated method stub
		return "A4ֽ";
	}

}
