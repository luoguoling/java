package com.bdqn.domain;

import com.bdqn.inf.InkBox;

public class CaiSeInkBox implements InkBox{
	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "��ɫī��";
	}
}
