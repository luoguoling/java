package com.bdqn.domain;

import com.bdqn.inf.IPaper;

public class B5Paper implements IPaper {

	@Override
	public String paperSize() {
		// TODO Auto-generated method stub
		return "B5ֽ";
	}

}
