package com.bdqn.domain;

import com.bdqn.inf.InkBox;

public class BWInkBox implements InkBox{
	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "�ڰ�ī��";
	}
}
