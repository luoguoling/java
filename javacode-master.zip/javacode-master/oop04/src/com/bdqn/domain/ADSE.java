package com.bdqn.domain;

import com.bdqn.inf.SE;
import com.bdqn.inf.ShiChang;

public class ADSE implements SE,ShiChang{
	@Override
	public void speakYW() {
		// TODO Auto-generated method stub
		System.out.println("�߱���ҵ���������");
	}
	@Override
	public void writerCoding() {
		// TODO Auto-generated method stub
		System.out.println("д���룡");
	}
}
