package com.bdqn.domain;

import com.bdqn.inf.SE;

public class ADSEV2 extends ADSE implements SE{
	public void hejiu(){
		
	}
}
