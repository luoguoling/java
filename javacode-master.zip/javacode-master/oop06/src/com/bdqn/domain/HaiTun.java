package com.bdqn.domain;

public class HaiTun extends DongWu{

	public HaiTun(String dName, String dSex) {
		super(dName, dSex);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void jiao() {
		// TODO Auto-generated method stub
		System.out.println("��������������");
	}
	
}
