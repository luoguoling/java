package com.bdqn.test;

public class Father {
	public void speak(){
		System.out.println("ֻ��˵���");
	}
	
	public void eat(){
		System.out.println("�Է�");
	}
}
