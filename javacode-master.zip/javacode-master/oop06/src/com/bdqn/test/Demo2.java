package com.bdqn.test;

public class Demo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test.func(2);
		System.out.println(Test.count);
	}

}
