package com.bdqn.inf;

public interface IPlayAble {
	public void play();
}
