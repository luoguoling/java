package com.bdqn.inf;

public interface IRun {
	public int getTuiNum();
}
