package com.bdqn.service.inf;

public interface IDBHelpEx extends IDBHelp {
	public int getRowCount();
	public int getRowCount(String sql);
}
