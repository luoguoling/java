package com.bdqn.service.inf;

public interface Computer {
	public void cunchu();
	public void view();
	public void input();
}
