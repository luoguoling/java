package com.bdqn.service.inf;


public interface DBHelpEXX{
	public String getClumnName(int ClumnIndex);
	public int getClumnCount();
}
