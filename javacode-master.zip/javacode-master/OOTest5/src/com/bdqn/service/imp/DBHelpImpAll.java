package com.bdqn.service.imp;

import com.bdqn.service.inf.IDBHelp;
import com.bdqn.service.inf.IDBHelpEx;
import com.bdqn.service.inf.DBHelpEXX;

public class DBHelpImpAll extends DBHelpImp implements IDBHelpEx,DBHelpEXX{

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount(String sql) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getClumnName(int ClumnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getClumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
