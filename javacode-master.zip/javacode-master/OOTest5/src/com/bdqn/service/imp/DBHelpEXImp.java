package com.bdqn.service.imp;

import java.sql.Connection;
import java.util.List;

import com.bdqn.service.inf.IDBHelpEx;

public class DBHelpEXImp extends DBHelpImp implements IDBHelpEx {
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount(String sql) {
		// TODO Auto-generated method stub
		return 0;
	}

}
