package com.bdqn.domain;

public final class CheBands {
	public static final int BMW = 1;
	public static final int BIEKE = 2;
	public static final int JINBEI = 3;
	public static final int JINLONG = 4;
}
