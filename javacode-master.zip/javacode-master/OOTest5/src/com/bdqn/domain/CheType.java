package com.bdqn.domain;

public final class CheType {
	public static final int BMW_550I = 0;
	public static final int BIEKE_GL8 = 1;
	public static final int BIEKE_LINYINDADAO = 2;
	public static final int JINBEI_16 = 16;
	public static final int JINLONG_24 = 24;
}
