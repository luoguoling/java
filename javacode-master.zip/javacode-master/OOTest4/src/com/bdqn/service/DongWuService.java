package com.bdqn.service;

import com.bdqn.domain.DongWu;

public class DongWuService {
	public void aiZhou(DongWu parDW){
		parDW.jiao();
	}
}
