package com.bdqn.service;

import com.bdqn.domain.Printer;

public class BankSystem {
	public void shouju(Printer myPrinter){
		myPrinter.print();
	}
}
