package com.bdqn.domain;

public class Cat extends DongWu {
	@Override
	public void jiao() {
		// TODO Auto-generated method stub
		System.out.println("è������");
	}
}
