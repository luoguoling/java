package com.bdqn.domain;

import java.sql.Connection;
import java.sql.DriverManager;

public abstract class WuQi {
	public abstract void fire();
}
