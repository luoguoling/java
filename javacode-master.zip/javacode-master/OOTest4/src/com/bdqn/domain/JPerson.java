package com.bdqn.domain;

public class JPerson extends Person {
	@Override
	public void langauge() {
		// TODO Auto-generated method stub
		System.out.println("˵�ձ�����");
	}
	public void eat() {
		System.out.println("�ýųԷ���");
	}
}
