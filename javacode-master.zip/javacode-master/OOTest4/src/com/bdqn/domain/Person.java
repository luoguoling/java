package com.bdqn.domain;

public class Person {
	private String renZhong = "";
	public void langauge(){
		System.out.println("˵�˻���");
	}
	public void eat(){
		System.out.println("�Է���");
	}
	public String getRenZhong() {
		return renZhong;
	}
	public void setRenZhong(String renZhong) {
		this.renZhong = renZhong;
	}
}
