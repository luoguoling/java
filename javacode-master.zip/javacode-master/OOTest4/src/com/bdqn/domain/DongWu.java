package com.bdqn.domain;

public class DongWu {
	private String name = "";
	public void jiao(){
		System.out.println("����У�");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
