package com.bdqn.domain;

public abstract class Printer {
	public abstract void print();
}
