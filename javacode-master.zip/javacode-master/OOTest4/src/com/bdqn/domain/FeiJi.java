package com.bdqn.domain;

public class FeiJi extends WuQi{
	@Override
	public void fire() {
		// TODO Auto-generated method stub
		System.out.println("�÷ɻ�Ͷ����");
	}
}
