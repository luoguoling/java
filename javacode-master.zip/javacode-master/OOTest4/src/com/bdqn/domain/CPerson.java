package com.bdqn.domain;

public class CPerson extends Person {
	@Override
	public void langauge() {
		// TODO Auto-generated method stub
		System.out.println("˵�й�����");
	}
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("�ÿ��ӳԷ���");
	}
}
