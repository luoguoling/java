package com.bdqn.core.inf;

import com.bdqn.game.inf.core.IGameService;

public interface IMyGameSerivce extends IGameService {
	public int addJF(int parYongTime);
}
