package com.bdqn.myconst;

public class EmpType {
	public static final int EMP_SE = 1;
	public static final int EMP_PM = 2;
	public static final int EMP_CW = 3;
	public static final int MAN = 1;
	public static final int WOMAN = 0;
	public static final int SUCC = 0;
	public static final int FAIL = 1;
	public static final int ERR = 2;
}
