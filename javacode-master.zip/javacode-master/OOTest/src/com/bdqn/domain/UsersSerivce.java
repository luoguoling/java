package com.bdqn.domain;

import java.sql.Connection;

public class UsersSerivce {
	private Connection conn = null;
	public boolean isLogin(){
		return false;
	}
}
