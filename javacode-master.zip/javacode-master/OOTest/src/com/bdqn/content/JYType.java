package com.bdqn.content;


public final class JYType {
	public static final String JYTYPE_CUNKUAN = "����";
	public static final String JYTYPE_QUKUAN = "ȡ��";
	public static final int JYTYPE_CODE_CUNKUN = 0;
	public static final int JYTYPE_CODE_QUNKUN = 1; 
}
