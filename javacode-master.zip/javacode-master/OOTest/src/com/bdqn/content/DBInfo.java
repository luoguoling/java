package com.bdqn.content;

public class DBInfo {
	public static final String SQL_URL = "jdbc:sqlserver://...";
}
