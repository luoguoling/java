package com.bdqn.test;

import com.bdqn.domain.Car;

public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car myCar = new Car("����i550");
		System.out.println(myCar.total(34));
	}

}
