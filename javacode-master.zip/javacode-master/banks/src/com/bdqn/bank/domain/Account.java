package com.bdqn.bank.domain;


public class Account {

}
