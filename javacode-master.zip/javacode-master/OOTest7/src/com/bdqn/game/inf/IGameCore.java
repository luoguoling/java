package com.bdqn.game.inf;

public interface IGameCore {
	public String getRandStr();
}
