package com.bdqn.consts;

public class DBConsts {
	public static final String DB_URL = "jdbc:oracle:thin:@127.0.0.1:1522:ORCL";
	public static final String DB_USER = "scott";
	public static final String DB_PWD = "tiger";
	public static final int MAN = 1;
	public static final int WOMAN = 0;
}
