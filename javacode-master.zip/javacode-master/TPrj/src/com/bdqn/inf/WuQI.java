package com.bdqn.inf;

public interface WuQI {
	public void fire();
}
