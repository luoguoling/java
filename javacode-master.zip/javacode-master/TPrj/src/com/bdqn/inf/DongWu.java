package com.bdqn.inf;

public interface DongWu {
	public void jiao();
}
