package com.bdqn.domain;

public class Users {
	private String userName = "";
	private String sex = "";
	private String birthday = "";
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getSex() {
		return sex;
	}
	private void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	private void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	
}
