package com.bdqn.domain;

import com.bdqn.inf.WuQI;

public class ShouQiang implements WuQI {

	@Override
	public void fire() {
		// TODO Auto-generated method stub
		System.out.println("���ӵ�!");
	}

}
